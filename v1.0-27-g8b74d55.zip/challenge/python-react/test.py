import pytest


@pytest.fixture()
def test_func1
	total = 1+1
	assert total == 2


