def add_two(x, y):
    return lambda x, y: x + y
